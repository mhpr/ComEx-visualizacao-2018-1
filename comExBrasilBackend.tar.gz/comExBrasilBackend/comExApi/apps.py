from django.apps import AppConfig


class ComexapiConfig(AppConfig):
    name = 'comExApi'
